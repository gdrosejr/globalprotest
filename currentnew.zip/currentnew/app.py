from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
import requests

os.path.join("static")

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///posts.db'

db = SQLAlchemy(app)

keywords = ["png", "jpg", "jpeg", "mp4", "mov"]


class BlogPost(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    place = db.Column(db.String(100))
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    imgname = db.Column(db.String(100))

    def __repr__(self):
        return 'Post id: ' + str(self.id) + "\n Place: " + str(self.place)+ "\n Title: " + str(self.title)+ "\n Content: " + str(self.content) + "\n IMG url: " + str(self.imgname)

@app.route('/')
def index():
    all_posts = BlogPost.query.all()
    return render_template('index.html', posts=all_posts)

@app.route('/test')
def test():
    return render_template('test.html')

# 404 Error handler
@app.errorhandler(404) 
def not_found(e):
    contents = requests.get('https://random.dog/woof.json').json()
    url = contents['url']
    return render_template("404.html", img=url)


# Upload posts (Title, content, place, media)
@app.route('/posts', methods=['GET', 'POST'])
def posts():
    if request.method == 'POST':
        f = request.files['file']  
        post_place = request.form['place']
        post_title = request.form['title']
        post_content = request.form['content']
        for i in keywords:
            if i in f.filename:
                keyword = i
        filename = post_title + "." + keyword
        filename = filename.replace(" ", "_")
        filename = "static\\uploads\\" + filename
        f.save(filename)
        new_post = BlogPost(place=post_place, title=post_title, content=post_content, imgname=filename)
        db.session.add(new_post)
        db.session.commit()
        return redirect('/posts')
    else:
        all_posts = BlogPost.query.order_by(BlogPost.date_posted).all()
        return render_template('posts.html', posts=all_posts)

# Delete
@app.route('/posts/delete/<int:id>')
def delete(id):
    post = BlogPost.query.get_or_404(id)
    db.session.delete(post)
    db.session.commit()
    return redirect('/posts')



# Not working right now
"""
@app.route('/posts/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    
    post = BlogPost.query.get_or_404(id)

    if request.method == 'POST':
        post_place = request.form['place']
        post_title = request.form['title']
        post_content = request.form['content']
        db.session.commit()
        return redirect('/posts')
    else: 
        return render_template('edit.html', post=post)
"""

@app.route('/news', methods=["GET", "POST"])
def news():
    all_posts = BlogPost.query.all()
    return render_template('news.html', posts=all_posts)

@app.route('/posts/<int:id>', methods=['GET', 'POST'])
def view(id):
    post = BlogPost.query.get_or_404(id)
    return render_template('view.html', post=post)

@app.route('/posts/<place>', methods=["GET", "POST"])
def viewplace(place):
    posts = BlogPost.query.get_or_404(place)
    return render_template('places.html', posts=posts)


if __name__ == "__main__":
    app.run(debug=True)